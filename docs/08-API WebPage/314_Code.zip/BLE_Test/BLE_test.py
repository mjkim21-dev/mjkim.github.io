# MicroPython BLE demo for ESP32-S3
# Compatible version (no unsupported config, safe advertising)

import bluetooth
import time
from machine import Pin
from micropython import const

# IRQ event constants
_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

# Nordic UART Service UUIDs
_UART_UUID = bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
_UART_TX = (bluetooth.UUID("6E400003-B5A3-F393-E0A9-E50E24DCCA9E"),
            bluetooth.FLAG_NOTIFY)
_UART_RX = (bluetooth.UUID("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"),
            bluetooth.FLAG_WRITE)
_UART_SERVICE = (_UART_UUID, (_UART_TX, _UART_RX))

# Pins
led8 = Pin(8, Pin.OUT, value=0)
led36 = Pin(36, Pin.OUT, value=0)
button = Pin(35, Pin.IN, Pin.PULL_UP)

button_pressed = False
last_button_ms = 0


def _advertising_payload(name=None, services=None):
    payload = bytearray()

    def _append(adv_type, value):
        payload.extend((len(value) + 1, adv_type))
        payload.extend(value)

    # Flags
    payload.extend(b"\x02\x01\x06")

    if name:
        _append(0x09, name.encode())

    if services:
        for uuid in services:
            b = bytes(uuid)
            if len(b) == 2:
                _append(0x03, b)
            elif len(b) == 16:
                _append(0x07, b)

    return bytes(payload)


class BLEDemo:
    def __init__(self, name="ESP32-S3-DEMO"):
        self.name = name
        self.ble = bluetooth.BLE()
        self.ble.active(True)
        self.ble.irq(self._irq)

        # Register service
        ((self.tx_handle, self.rx_handle),) = self.ble.gatts_register_services((_UART_SERVICE,))
        self.ble.gatts_set_buffer(self.rx_handle, 128, True)

        self.conn_handle = None
        self.advertise()

    def advertise(self):
        # Keep advertising small to avoid overflow
        adv = _advertising_payload(name=self.name)

        try:
            # Use positional args ONLY (important)
            self.ble.gap_advertise(100_000, adv)
            print("Advertising as", self.name)
        except Exception as e:
            print("Advertising failed:", e)

    def _irq(self, event, data):
        global button_pressed

        if event == _IRQ_CENTRAL_CONNECT:
            conn_handle, addr_type, addr = data
            self.conn_handle = conn_handle
            print("BLE connected")
            led8.value(1)

        elif event == _IRQ_CENTRAL_DISCONNECT:
            print("BLE disconnected")
            self.conn_handle = None
            led8.value(0)
            self.advertise()

        elif event == _IRQ_GATTS_WRITE:
            conn_handle, attr_handle = data

            if attr_handle == self.rx_handle:
                raw = self.ble.gatts_read(self.rx_handle)

                try:
                    msg = raw.decode().strip()
                except Exception:
                    msg = ""

                print("RX:", raw)

                if msg == "8=1":
                    led8.value(1)
                    reply = "OK led8=1"
                elif msg == "8=0":
                    led8.value(0)
                    reply = "OK led8=0"
                elif msg == "36=1":
                    led36.value(1)
                    reply = "OK led36=1"
                elif msg == "36=0":
                    led36.value(0)
                    reply = "OK led36=0"
                elif msg == "toggle8":
                    led8.value(not led8.value())
                    reply = "OK led8 toggled"
                elif msg == "toggle36":
                    led36.value(not led36.value())
                    reply = "OK led36 toggled"
                elif msg == "status":
                    reply = "status: led8={}, led36={}, button={}".format(
                        led8.value(), led36.value(), button.value()
                    )
                else:
                    reply = "echo: " + msg if msg else "rx bytes"

                self.ble.gatts_write(self.tx_handle, reply.encode())

                if self.conn_handle is not None:
                    try:
                        self.ble.gatts_notify(self.conn_handle, self.tx_handle)
                    except Exception as e:
                        print("Notify failed:", e)

    def notify(self, text):
        if self.conn_handle is not None:
            if isinstance(text, str):
                text = text.encode()

            try:
                self.ble.gatts_write(self.tx_handle, text)
                self.ble.gatts_notify(self.conn_handle, self.tx_handle)
                print("TX:", text)
            except Exception as e:
                print("Notify error:", e)


def button_irq(pin):
    global button_pressed, last_button_ms

    now = time.ticks_ms()
    if time.ticks_diff(now, last_button_ms) > 200:
        last_button_ms = now
        button_pressed = True


button.irq(trigger=Pin.IRQ_FALLING, handler=button_irq)

ble = BLEDemo()

last_heartbeat = time.ticks_ms()
heartbeat_count = 0

while True:
    if button_pressed:
        button_pressed = False
        led36.value(not led36.value())
        ble.notify("button pressed")

    if time.ticks_diff(time.ticks_ms(), last_heartbeat) > 2000:
        last_heartbeat = time.ticks_ms()
        heartbeat = "heartbeat {}".format(heartbeat_count)
        heartbeat_count += 1
        ble.notify(heartbeat)

    time.sleep_ms(20)