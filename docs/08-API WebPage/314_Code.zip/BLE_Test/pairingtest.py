import bluetooth
import asyncio
import aioble
from machine import Pin

# Must match the Peripheral's UUIDs exactly
_BLE_SERVICE_UUID = bluetooth.UUID('8bbd8ff7-3d84-4e81-9d46-70b6cb79e76a')
_BLE_UPSTREAM_UUID = bluetooth.UUID('5699aead-41fc-4705-9c65-7c84d8bcb04c')

# Pins
led_red = Pin(8, Pin.OUT, value=0)     # Connection Status
led_green = Pin(36, Pin.OUT, value=1)  # Power Status
button = Pin(35, Pin.IN, Pin.PULL_UP)

async def find_peripheral():
    """Scans for the Peripheral running your specific service."""
    print("Scanning for peripheral...")
    async with aioble.scan(5000, interval_us=30000, window_us=30000, active=True) as scanner:
        async for result in scanner:
            # Match by Service UUID
            if _BLE_SERVICE_UUID in result.services():
                print(f"Found Peripheral: {result.name()} ({result.device})")
                return result.device
    return None

async def monitor_connection(connection):
    """Keeps the connection alive and handles data."""
    try:
        # Discover the service and characteristics on the peripheral
        service = await connection.service(_BLE_SERVICE_UUID)
        upstream_char = await service.characteristic(_BLE_UPSTREAM_UUID)
        
        led_red.value(1) # Solid Red = Connected
        
        while connection.is_connected():
            # Example: Try to read data from the peripheral
            data = await upstream_char.read()
            if data:
                print(f"Received from peripheral: {data}")
            
            # Use small sleeps to prevent CPU hogging
            await asyncio.sleep(1)
            
    except Exception as e:
        print(f"Connection lost or error: {e}")
    finally:
        led_red.value(0) # Off = Disconnected

async def main():
    while True:
        # 1. Look for the device
        device = await find_peripheral()
        
        if device:
            try:
                # 2. Attempt to connect
                print(f"Connecting to {device}...")
                connection = await device.connect(timeout_ms=5000)
                print("Connected!")
                
                # 3. Handle the connection logic
                await monitor_connection(connection)
                
            except asyncio.TimeoutError:
                print("Connection timed out.")
            except Exception as e:
                print(f"Failed to connect: {e}")
        
        print("Retrying scan in 2 seconds...")
        await asyncio.sleep(2)

# Start the event loop
try:
    asyncio.run(main())
except KeyboardInterrupt:
    print("Stopped.")