# MicroPython BLE demo for ESP32-S3
import bluetooth
import time
from machine import Pin
from micropython import const
import asyncio
import aioble
import struct

# IRQ event constants
_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
#_IRQ_GATTS_WRITE = const(3)

# BLE Service UUIDs   
_BLE_SERVICE_UUID = bluetooth.UUID('8bbd8ff7-3d84-4e81-9d46-70b6cb79e76a')
_BLE_UPSTREAM_UUID = bluetooth.UUID('5699aead-41fc-4705-9c65-7c84d8bcb04c')
_BLE_DOWNSTREAM_UUID = bluetooth.UUID('a037a1df-ccaf-480c-b7a4-6526a6848887')
_BLE_HEARTBEAT_UUID = bluetooth.UUID('24ef4bcf-9f6e-4dec-894f-090aadfbf75d')
_BLE_ROLLCALL_UUID = bluetooth.UUID('d9cba376-e9c9-4db7-a6f2-4c6783c1dade')
_BLE_A3_ADDRESS = aioble.Device(aioble.ADDR_PUBLIC, "D4:8C:49:E4:D3:8A") 
_ADV_INTERVAL_MS = 250_000

# Pins
led_red = Pin(8, Pin.OUT, value=0)      # Pin 8: Connection Status
led_green = Pin(36, Pin.OUT, value=1)   # Pin 36: BLE Power Status (Start ON)
button = Pin(35, Pin.IN, Pin.PULL_UP)

button_pressed = False
last_button_ms = 0

# UART daisy-chain

# BLE
ble_service = aioble.Service(_BLE_SERVICE_UUID)
upstream_characteristic = aioble.Characteristic(ble_service, _BLE_UPSTREAM_UUID, read=True, notify=True)
# capture property allows other ble devices to write to this charecteristic
downstream_characteristic = aioble.Characteristic(ble_service, _BLE_DOWNSTREAM_UUID, read=True, write=True, notify=True, capture=True)
aioble.register_services(ble_service)

downstream_msg = bytearray(4)
test_ba = bytearray(4)
test_ba[1]=65
upstream_msg = bytearray(4)

async def central_task():
    # Start scanning for a device with the matching service UUID
    while True:
       try:
           connection = await device.connect(timeout_ms=2000)
       except asyncio.TimeoutError:
           print('Timeout')
       break
     

# Defining asyncio task to advertise device for pairing (How to pair A2???)
# Serially wait for connections
# Advertising stopped when central connected (ie, a phone)

async def upstream_read():
	while True:
		try:
			connection, data = await upstream_characteristic.written()
			print('connection: ', connection)
			print('data: ', data)
			upstream_msg = data
			print('upstream message: ',upstream_msg)
			# handle data here, send to uart
		except asyncio.CancelledError:
			print("Peripheral task cancelled")
		except Exception as e:
			print("Error in  peripheral_task:", e)
		finally:
			await asyncio.sleep_ms(100)

# Main
async def main():
#OPTIMIZE: gather appears to be bad practice in python3, change this to a task group if time permits
	#t1 = asyncio.create_task(upstream_write())
	t2 = asyncio.create_task(central_task())
	t3 = asyncio.create_task(upstream_read())
	#await asyncio.gather(t2)

asyncio.run(main())







# def button_irq(pin):
#     global button_pressed, last_button_ms
#     now = time.ticks_ms()
#     if time.ticks_diff(now, last_button_ms) > 200:
#         last_button_ms = now
#         button_pressed = True
# 
# button.irq(trigger=Pin.IRQ_FALLING, handler=button_irq)
# 
# ble = BLEDemo()
# last_heartbeat = time.ticks_ms()
# 
# while True:
#     if button_pressed:
#         button_pressed = False
#         # Use the new toggle method
#         ble.toggle_ble()
# 
#     # Only send heartbeat if BLE is actually ON and connected
#     if ble.is_active and ble.conn_handle is not None:
#         if time.ticks_diff(time.ticks_ms(), last_heartbeat) > 2000:
#             last_heartbeat = time.ticks_ms()
#             ble.notify("heartbeat")
# 
#     time.sleep_ms(20)