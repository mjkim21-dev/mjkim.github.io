import asyncio
import machine

# --- INITIALIZATION AND GLOBAL CONSTANTS ---
uart = machine.UART(1, baudrate=9600, tx=43, rx=44) #can also use 14 on either rx or tx for downstream header use
led_rx = machine.Pin(36, machine.Pin.OUT)
led_heart = machine.Pin(8, machine.Pin.OUT)
button = machine.Pin(35, machine.Pin.IN, machine.Pin.PULL_UP) # Pin 35 is button on my board

LEN   = 4    #buffer

async def blink_rx():
    led_rx.value(1)
    await asyncio.sleep(0.05)
    led_rx.value(0)
    
def process_packet(packet):
    print("Received raw packet:", packet)
    
    # 1. Remove the 'AZ' and 'YB' markers
    # We take the slice from index 2 to -2
    core = packet[2:-2].strip('|')
    parts = core.split('|')
    
    # 2. Check if we have enough data to be a valid message
    if len(parts) >= 4:
        sender = parts[0]
        receiver = parts[1]
        ptype = parts[2]
        info = "|".join(parts[3:]) # Rejoin extra data if needed
        
        print(f"FROM: {sender} | TO: {receiver} | TYPE: {ptype} | INFO: {info}")
        
        # 3. Trigger your RX LED blink
        asyncio.create_task(blink_rx())
    else:
        print("Received unstructured or incomplete message.")

#Debug code
# async def uart_handler():
#     while True:
#         if uart.any():
#             data = uart.read()
#             # Print everything that comes in
#             print(f"DEBUG RX: {data}")
#         await asyncio.sleep(0.1)

async def uart_handler():
    buffer = bytearray()
    collecting = False

    while True:
        if uart.any():
            data = uart.read()
            for b in data:
                if not collecting:
                    buffer.append(b)
                    # Only start collecting if the last two bytes ARE "AZ"
                    if len(buffer) >= 2 and buffer[-2:] == b'AZ':
                        collecting = True
                        # Clear any noise that happened before the AZ
                        buffer = bytearray(b'AZ') 
                else:
                    buffer.append(b)
                    # End Detection
                    if len(buffer) >= 4 and buffer[-2:] == b'YB':
                        packet = buffer.decode('utf-8', 'ignore') # 'ignore' prevents crashing on bad data
                        process_packet(packet)
                        collecting = False
                        buffer = bytearray()
                        
                # Safety: If buffer gets too huge, clear it (prevents memory leaks)
                if len(buffer) > 100: 
                    buffer = bytearray()
                    collecting = False
        await asyncio.sleep(0)

async def button_handler():
    last_state = 1
    while True:
        current_state = button.value()
        if current_state == 0 and last_state == 1: # Falling edge (press)
            uart.write(b'AZ|B|F|DIR|fish|YB') # Change "third section" for changing TO: reciever 
            print("Button Pressed: Packet Sent")
            await asyncio.sleep(0.2) # Simple debounce
        last_state = current_state
        await asyncio.sleep_ms(20)

async def heartbeat(): #heartbeat, shown with Red LED
    while True:
        led_heart.value(not led_heart.value())
        await asyncio.sleep(0.5)

async def main():
    print("Bi-directional System Ready.")
    await asyncio.gather(
        uart_handler(),
        button_handler(), # Now waiitng for button press
        heartbeat()
    )

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        led_heart.value(0)
        print("System Offline.") #when pressing stop on thonny, system will shut down