# MicroPython BLE demo for ESP32-S3 mk
import bluetooth
import time
from machine import Pin
from micropython import const
import asyncio
import aioble
import struct

# IRQ event constants
_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

# Nordic UART Service UUIDs
_UART_UUID = bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
_UART_TX = (bluetooth.UUID("6E400003-B5A3-F393-E0A9-E50E24DCCA9E"), bluetooth.FLAG_NOTIFY)
_UART_RX = (bluetooth.UUID("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"), bluetooth.FLAG_WRITE)
_UART_SERVICE = (_UART_UUID, (_UART_TX, _UART_RX))

# Pins
led_red = Pin(8, Pin.OUT, value=0)      # Pin 8: Connection Status
led_green = Pin(36, Pin.OUT, value=1)   # Pin 36: BLE Power Status (Start ON)
button = Pin(35, Pin.IN, Pin.PULL_UP)

button_pressed = False
last_button_ms = 0

def _advertising_payload(name=None, services=None):
    payload = bytearray()
    def _append(adv_type, value):
        payload.extend((len(value) + 1, adv_type))
        payload.extend(value)
    payload.extend(b"\x02\x01\x06")
    if name:
        _append(0x09, name.encode())
    if services:
        for uuid in services:
            b = bytes(uuid)
            if len(b) == 2: _append(0x03, b)
            elif len(b) == 16: _append(0x07, b)
    return bytes(payload)

class BLEDemo:
    def __init__(self, name="Singapore Spyware"):
        self.name = name
        self.ble = bluetooth.BLE()
        self.ble.active(True) # Start active
        self.ble.irq(self._irq)
        ((self.tx_handle, self.rx_handle),) = self.ble.gatts_register_services((_UART_SERVICE,))
        self.ble.gatts_set_buffer(self.rx_handle, 128, True)
        self.conn_handle = None
        self.is_active = True
        self.advertise()

    def toggle_ble(self):
        self.is_active = not self.is_active
        if self.is_active:
            self.ble.active(True)
            self.advertise()
            led_green.value(1) # Green ON when BLE is active
            print("BLE Powered ON")
        else:
            self.ble.active(False)
            led_green.value(0) # Green OFF when BLE is inactive
            led_red.value(0)   # Force Red OFF since connection is lost
            print("BLE Powered OFF")

    def advertise(self):
        if not self.is_active: return
        adv = _advertising_payload(name=self.name)
        try:
            self.ble.gap_advertise(100_000, adv)
            print("Advertising as", self.name)
        except Exception as e:
            print("Advertising failed:", e)

    def _irq(self, event, data):
        if event == _IRQ_CENTRAL_CONNECT:
            self.conn_handle, _, _ = data
            led_red.value(1) # Red ON when connected
            print("BLE connected")

        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.conn_handle = None
            led_red.value(0) # Red OFF when disconnected
            print("BLE disconnected")
            if self.is_active:
                self.advertise()

        elif event == _IRQ_GATTS_WRITE:
            conn_handle, attr_handle = data
            if attr_handle == self.rx_handle:
                raw = self.ble.gatts_read(self.rx_handle)
                # ... (rest of your RX logic remains the same)
                self.ble.gatts_write(self.tx_handle, b"ACK")
                if self.conn_handle is not None:
                    self.ble.gatts_notify(self.conn_handle, self.tx_handle)

    def notify(self, text):
        if self.conn_handle is not None and self.is_active:
            if isinstance(text, str): text = text.encode()
            try:
                self.ble.gatts_write(self.tx_handle, text)
                self.ble.gatts_notify(self.conn_handle, self.tx_handle)
            except: pass

def button_irq(pin):
    global button_pressed, last_button_ms
    now = time.ticks_ms()
    if time.ticks_diff(now, last_button_ms) > 200:
        last_button_ms = now
        button_pressed = True

button.irq(trigger=Pin.IRQ_FALLING, handler=button_irq)

ble = BLEDemo()
last_heartbeat = time.ticks_ms()

while True:
    if button_pressed:
        button_pressed = False
        # Use the new toggle method
        ble.toggle_ble()

    # Only send heartbeat if BLE is actually ON and connected
    if ble.is_active and ble.conn_handle is not None:
        if time.ticks_diff(time.ticks_ms(), last_heartbeat) > 2000:
            last_heartbeat = time.ticks_ms()
            ble.notify("heartbeat")

    time.sleep_ms(20)